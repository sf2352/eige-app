// EIGE: проверка Telegram и работа только со своей анкетой.
const allowedOrigins = new Set(['https://cute-phoenix-415a68.netlify.app', 'https://super-creponne-b8cea5.netlify.app', 'https://sf2352.github.io']);
const encoder = new TextEncoder();

Deno.serve(async (req) => {
  const origin = req.headers.get('origin');
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': origin && allowedOrigins.has(origin) ? origin : 'https://super-creponne-b8cea5.netlify.app',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'content-type, apikey, authorization, x-client-info',
    'Vary': 'Origin',
    'Cache-Control': 'no-store'
  };
  const reply = (data, status = 200) =>
    new Response(JSON.stringify(data), { status, headers });

  if (origin && !allowedOrigins.has(origin)) return reply({ error: 'Origin not allowed' }, 403);
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers });
  if (req.method !== 'POST') return reply({ error: 'Method not allowed' }, 405);

  try {
    const token = Deno.env.get('TELEGRAM_BOT_TOKEN');
    if (!token) return reply({ error: 'Server configuration error' }, 500);

    const raw = await req.text();
    if (raw.length > 98304) return reply({ error: 'Request too large' }, 413);
    const body = JSON.parse(raw);
    const initData = body?.initData;
    if (typeof initData !== 'string' || initData.length > 8192) {
      return reply({ error: 'Invalid Telegram data' }, 401);
    }

    const params = new URLSearchParams(initData);
    const entries = [...params.entries()];
    if (new Set(entries.map(([key]) => key)).size !== entries.length) {
      return reply({ error: 'Invalid Telegram data' }, 401);
    }
    const hash = params.get('hash');
    const authDate = params.get('auth_date');
    if (!hash || !/^[a-fA-F0-9]{64}$/.test(hash) || !authDate || !/^\d+$/.test(authDate)) {
      return reply({ error: 'Invalid Telegram data' }, 401);
    }
    const age = Math.floor(Date.now() / 1000) - Number(authDate);
    if (age < -60 || age > 86400) return reply({ error: 'Telegram data expired' }, 401);

    params.delete('hash');
    const dataCheckString = [...params.entries()]
      .sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)
      .map(([key, value]) => `${key}=${value}`)
      .join('\n');

    const baseKey = await crypto.subtle.importKey(
      'raw', encoder.encode('WebAppData'), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    );
    const secret = await crypto.subtle.sign('HMAC', baseKey, encoder.encode(token));
    const hmacKey = await crypto.subtle.importKey(
      'raw', secret, { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']
    );
    const hashBytes = Uint8Array.from(hash.match(/.{2}/g) || [], hex => parseInt(hex, 16));
    const valid = await crypto.subtle.verify('HMAC', hmacKey, hashBytes, encoder.encode(dataCheckString));
    if (!valid) return reply({ error: 'Invalid Telegram data' }, 401);

    const user = JSON.parse(params.get('user') || 'null');
    if (!user || !Number.isSafeInteger(user.id) || user.id <= 0) {
      return reply({ error: 'Invalid Telegram user' }, 401);
    }
    const action = body.action || 'check';
    if (action === 'check') {
      return reply({ ok: true, user: { id: user.id, first_name: String(user.first_name || '').slice(0, 100) } });
    }
    if (!['get_profile', 'save_profile', 'list_profiles', 'set_visibility', 'set_status', 'list_projects', 'create_project', 'apply_project', 'project_requests', 'decide_request', 'withdraw_request', 'project_chat_list', 'project_chat_send', 'list_my_projects', 'edit_project', 'delete_project', 'admin_login', 'admin_list_profiles', 'admin_list_projects', 'admin_verify', 'admin_delete_profile', 'admin_delete_project', 'delete_my_account', 'leave_project', 'remove_project_member', 'report_content', 'admin_list_reports', 'admin_review_report', 'project_chat_report', 'project_chat_react', 'project_group_get', 'project_group_set', 'project_chat_settings_get', 'project_chat_notifications_set', 'project_chat_rules_set', 'admin_list_chat_reports', 'admin_handle_chat_report', 'admin_list_chat_blocks', 'admin_unblock_chat', 'match_team', 'avatars'].includes(action)) {
      return reply({ error: 'Unknown action' }, 400);
    }

    // Only the server holds the privileged key. Never trust an ID from the browser.
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');
    if (!serviceKey || !supabaseUrl) return reply({ error: 'Server configuration error' }, 500);
    const baseUrl = supabaseUrl + '/rest/v1/eige_profiles';
    const databaseHeaders = {
      'apikey': serviceKey,
      'Authorization': 'Bearer ' + serviceKey,
      'Content-Type': 'application/json',
    };
    // Deliver notifications after the response when the runtime allows it; otherwise wait as before.
    const background = (work) => {
      try {
        const runtime = globalThis.EdgeRuntime;
        if (runtime && typeof runtime.waitUntil === 'function') { runtime.waitUntil(work.catch(() => {})); return Promise.resolve(); }
      } catch (_) { /* fall back to awaiting */ }
      return work;
    };
    // Best-effort only. Never include message contents or participants' names in alerts.
    async function notifyModerators() {
      try {
        const admins=[...new Set((Deno.env.get('EIGE_ADMIN_TELEGRAM_IDS')||'').split(',').map(x=>x.trim()).filter(x=>/^\d+$/.test(x)).map(Number).filter(x=>Number.isSafeInteger(x)&&x>0))];
        for(let i=0;i<admins.length;i+=20) {
          await Promise.allSettled(admins.slice(i,i+20).map(chatId=>fetch('https://api.telegram.org/bot'+token+'/sendMessage',{
            method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({chat_id:chatId,text:'EIGE: поступила новая жалоба. Откройте админ-панель для проверки.'}),
            signal:AbortSignal.timeout(3000)
          })));
        }
      } catch (_) { /* The complaint is saved regardless of delivery. */ }
    }
    // Skills are short lowercase tags; the same normalization is applied in the database.
    const normalizeSkills = (list) => {
      if (list === undefined || list === null) return [];
      if (!Array.isArray(list) || list.length > 40) return null;
      const out = [];
      for (const raw of list) {
        if (typeof raw !== 'string' || raw.length > 60) return null;
        const v = raw.trim().replace(/\s+/g, ' ').toLowerCase();
        if (!v) continue;
        if (v.length > 30 || !/^[\p{L}\p{N}][\p{L}\p{N} .+#/-]*$/u.test(v)) return null;
        if (!out.includes(v)) out.push(v);
      }
      return out.length > 20 ? null : out;
    };
    if (action.startsWith('admin_')) {
      const adminPassword = Deno.env.get('EIGE_ADMIN_PASSWORD') || '';
      const adminIds = (Deno.env.get('EIGE_ADMIN_TELEGRAM_IDS') || '').split(',').map(s => s.trim()).filter(Boolean);
      // Both a server-side allowlist and password are required; no default admin.
      if (adminPassword.length < 20 || adminPassword.length > 256 || !adminIds.includes(String(user.id))) {
        return reply({error:'Admin access denied'},403);
      }
      const cryptoParams = {name:'HMAC',hash:'SHA-256'};
      const key = await crypto.subtle.importKey('raw',encoder.encode(adminPassword),cryptoParams,false,['sign','verify']);
      const rpc = async (name, params) => fetch(supabaseUrl + '/rest/v1/rpc/' + name, {
        method:'POST', headers:databaseHeaders, body:JSON.stringify(params)
      });
      if (action === 'admin_login') {
        if (typeof body.password !== 'string' || body.password.length > 256 || !body.password.length) return reply({error:'Admin access denied'},403);
        const limit = await rpc('eige_admin_try_login',{p_telegram_id:user.id});
        if (!limit.ok) return reply({error:'Admin service unavailable'},503);
        if ((await limit.json()) !== true) return reply({error:'Admin access denied'},403);
        const candidate = await crypto.subtle.importKey('raw',encoder.encode(body.password),cryptoParams,false,['sign']);
        const challenge = encoder.encode('EIGE admin password check v1');
        const candidateSignature = await crypto.subtle.sign('HMAC',candidate,challenge);
        if (!(await crypto.subtle.verify('HMAC',key,candidateSignature,challenge))) return reply({error:'Admin access denied'},403);
        const expires = Math.floor(Date.now()/1000) + 600;
        const material = encoder.encode('EIGE admin session v1:' + user.id + ':' + expires);
        const signature = new Uint8Array(await crypto.subtle.sign('HMAC',key,material));
        const hex = [...signature].map(n=>n.toString(16).padStart(2,'0')).join('');
        return reply({ok:true,session:String(expires)+'.'+hex,expires_at:expires});
      }
      const session = typeof body.admin_session === 'string' ? body.admin_session : '';
      const match = /^(\d{10,12})\.([a-f0-9]{64})$/.exec(session);
      if (!match) return reply({error:'Admin access denied'},403);
      const expires = Number(match[1]), now = Math.floor(Date.now()/1000);
      if (!Number.isSafeInteger(expires) || expires < now || expires > now + 600) return reply({error:'Admin access denied'},403);
      const sig = Uint8Array.from(match[2].match(/.{2}/g), hex => parseInt(hex,16));
      const validSession = await crypto.subtle.verify('HMAC',key,sig,encoder.encode('EIGE admin session v1:' + user.id + ':' + expires));
      if (!validSession) return reply({error:'Admin access denied'},403);
      const uuid = value => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
      const offset = Number.isSafeInteger(body.offset) && body.offset >= 0 && body.offset <= 100000 ? body.offset : 0;
      const reportStatus = body.report_status === 'reviewed' ? 'reviewed' : 'open';
      if (action === 'admin_list_chat_reports') {
        const r=await fetch(supabaseUrl+'/rest/v1/eige_chat_reports?status=eq.'+reportStatus+'&select=id,message_id,reason,created_at,reviewed_at&order=created_at.desc&limit=100&offset='+offset,{headers:databaseHeaders});
        if(!r.ok)return reply({error:'Database error'},502);
        const rows=await r.json(), messageIds=[...new Set(rows.map(x=>x.message_id).filter(uuid))];let messages=[],profiles=[],projects=[];
        if(messageIds.length){const q=await fetch(supabaseUrl+'/rest/v1/eige_project_messages?id=in.('+messageIds.join(',')+')&select=id,project_id,sender_id,body,created_at',{headers:databaseHeaders});if(!q.ok)return reply({error:'Database error'},502);messages=await q.json();}
        const ids=[...new Set(messages.map(x=>x.sender_id).filter(uuid))], projectIds=[...new Set(messages.map(x=>x.project_id).filter(uuid))];
        if(ids.length){const q=await fetch(baseUrl+'?id=in.('+ids.join(',')+')&select=id,name',{headers:databaseHeaders});if(!q.ok)return reply({error:'Database error'},502);profiles=await q.json();}
        if(projectIds.length){const q=await fetch(supabaseUrl+'/rest/v1/eige_projects?id=in.('+projectIds.join(',')+')&select=id,title',{headers:databaseHeaders});if(!q.ok)return reply({error:'Database error'},502);projects=await q.json();}
        return reply({ok:true,reports:rows.map(r=>{const m=messages.find(x=>x.id===r.message_id);return {id:r.id,reason:r.reason,created_at:r.created_at,message:m?{text:m.body,name:profiles.find(p=>p.id===m.sender_id)?.name||'Участник',project:projects.find(p=>p.id===m.project_id)?.title||'Проект'}:null};})});
      }
      if (action === 'admin_handle_chat_report') {
        if(!uuid(body.report_id)||!['review','delete','block'].includes(body.decision))return reply({error:'Invalid request'},400);
        const r=await rpc('eige_admin_handle_chat_report',{p_report_id:body.report_id,p_action:body.decision,p_actor_telegram_id:user.id});
        if(!r.ok)return reply({error:'Database error'},502);if((await r.json())!==true)return reply({error:'Report not found'},404);return reply({ok:true});
      }
      if (action === 'admin_list_chat_blocks') {
        const r=await fetch(supabaseUrl+'/rest/v1/eige_chat_blocks?select=id,telegram_id,created_at&order=created_at.desc&limit=100&offset='+offset,{headers:databaseHeaders});
        if(!r.ok)return reply({error:'Database error'},502);const rows=await r.json();
        const ids=[...new Set(rows.map(x=>x.telegram_id).filter(x=>Number.isSafeInteger(x)&&x>0))];let profiles=[];
        if(ids.length){const q=await fetch(baseUrl+'?telegram_id=in.('+ids.join(',')+')&select=telegram_id,name',{headers:databaseHeaders});if(!q.ok)return reply({error:'Database error'},502);profiles=await q.json();}
        return reply({ok:true,blocks:rows.map(x=>({id:x.id,name:profiles.find(p=>p.telegram_id===x.telegram_id)?.name||'Аккаунт удалён или скрыт',created_at:x.created_at}))});
      }
      if (action === 'admin_unblock_chat') {
        if(!uuid(body.block_id))return reply({error:'Invalid request'},400);
        const r=await rpc('eige_admin_unblock_chat',{p_block_id:body.block_id,p_actor_telegram_id:user.id});
        if(!r.ok)return reply({error:'Database error'},502);if((await r.json())!==true)return reply({error:'Report not found'},404);return reply({ok:true});
      }
      if (action === 'admin_list_reports') {
        const r = await fetch(supabaseUrl + '/rest/v1/eige_reports?status=eq.' + reportStatus + '&select=id,target_kind,target_id,reason,created_at,reviewed_at&order=created_at.desc&limit=100&offset=' + offset,{headers:databaseHeaders});
        if (!r.ok) return reply({error:'Database error'},502);
        const reports = await r.json();
        const profileIds=[...new Set(reports.filter(x=>x.target_kind==='profile'&&uuid(x.target_id)).map(x=>x.target_id))];
        const projectIds=[...new Set(reports.filter(x=>x.target_kind==='project'&&uuid(x.target_id)).map(x=>x.target_id))];
        let profiles=[],projects=[];
        if (profileIds.length) {
          const q=await fetch(baseUrl+'?id=in.('+profileIds.join(',')+')&select=id,name,role,profession',{headers:databaseHeaders});
          if(!q.ok)return reply({error:'Database error'},502);profiles=await q.json();
        }
        if (projectIds.length) {
          const q=await fetch(supabaseUrl+'/rest/v1/eige_projects?id=in.('+projectIds.join(',')+')&select=id,title,description',{headers:databaseHeaders});
          if(!q.ok)return reply({error:'Database error'},502);projects=await q.json();
        }
        return reply({ok:true,reports:reports.map(x=>({id:x.id,target_kind:x.target_kind,target_id:x.target_id,reason:x.reason,created_at:x.created_at,target:x.target_kind==='profile' ? profiles.find(p=>p.id===x.target_id)||null : projects.find(p=>p.id===x.target_id)||null}))});
      }
      if (action === 'admin_review_report') {
        if(!uuid(body.report_id))return reply({error:'Invalid request'},400);
        const r=await rpc('eige_admin_review_report',{p_report_id:body.report_id,p_actor_telegram_id:user.id});
        if(!r.ok)return reply({error:'Database error'},502);
        if((await r.json())!==true)return reply({error:'Report not found'},404);
        return reply({ok:true});
      }
      if (action === 'admin_list_profiles') {
        const r = await fetch(baseUrl + '?select=id,name,role,profession,role_verified&order=created_at.desc&limit=100&offset=' + offset,{headers:databaseHeaders});
        if (!r.ok) return reply({error:'Database error'},502);
        return reply({ok:true,profiles:await r.json()});
      }
      if (action === 'admin_list_projects') {
        const r = await fetch(supabaseUrl + '/rest/v1/eige_projects?select=id,title,category&order=created_at.desc&limit=100&offset=' + offset,{headers:databaseHeaders});
        if (!r.ok) return reply({error:'Database error'},502);
        return reply({ok:true,projects:await r.json()});
      }
      if (action === 'admin_verify') {
        if (!uuid(body.profile_id) || typeof body.verified !== 'boolean' || !['Педагог','Специалист / предприниматель'].includes(body.expected_role) || typeof body.expected_name !== 'string' || body.expected_name.length > 70 || typeof body.expected_profession !== 'string' || body.expected_profession.length > 90) return reply({error:'Invalid request'},400);
        const r = await rpc('eige_admin_verify_role',{p_profile_id:body.profile_id,p_verified:body.verified,p_actor_telegram_id:user.id,p_expected_role:body.expected_role,p_expected_name:body.expected_name,p_expected_profession:body.expected_profession});
        if (!r.ok) return reply({error:'Database error'},502);
        if ((await r.json()) !== true) return reply({error:'Role cannot be verified'},400);
        return reply({ok:true});
      }
      if (action === 'admin_delete_profile') {
        if (!uuid(body.profile_id)) return reply({error:'Invalid request'},400);
        const r = await rpc('eige_admin_delete_profile',{p_profile_id:body.profile_id,p_actor_telegram_id:user.id});
        if (!r.ok) return reply({error:'Database error'},502);
        if (!(await r.json())) return reply({error:'Cannot delete profile'},400);
        return reply({ok:true});
      }
      if (action === 'admin_delete_project') {
        if (!uuid(body.project_id)) return reply({error:'Invalid request'},400);
        const r = await rpc('eige_admin_delete_project',{p_project_id:body.project_id,p_actor_telegram_id:user.id});
        if (!r.ok) return reply({error:'Database error'},502);
        if (!(await r.json())) return reply({error:'Project not found'},404);
        return reply({ok:true});
      }
      return reply({error:'Unknown action'},400);
    }
    if (action === 'report_content') {
      const uuid = v => typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
      if (!uuid(body.target_id) || !['profile','project'].includes(body.target_kind) || !['spam','unsafe','inappropriate','other'].includes(body.reason)) return reply({error:'Invalid report'},400);
      const r=await fetch(supabaseUrl+'/rest/v1/rpc/eige_create_report',{method:'POST',headers:databaseHeaders,body:JSON.stringify({p_telegram_id:user.id,p_target_kind:body.target_kind,p_target_id:body.target_id,p_reason:body.reason})});
      if(!r.ok)return reply({error:'Database error'},502);
      const result=await r.json();
      if(result==='rate_limited')return reply({error:'Report limit'},429);
      if(result==='no_profile')return reply({error:'Profile not found'},404);
      if(result==='own_target')return reply({error:'Own target'},400);
      if(result==='not_found')return reply({error:'Report target not found'},404);
      if(result!=='ok')return reply({error:'Invalid report'},400);
      await background(notifyModerators());
      return reply({ok:true});
    }
    if (action === 'delete_my_account') {
      // Identity comes exclusively from verified Telegram initData.
      const r = await fetch(supabaseUrl + '/rest/v1/rpc/eige_delete_my_account', {
        method:'POST', headers:databaseHeaders, body:JSON.stringify({p_telegram_id:user.id})
      });
      if (!r.ok) return reply({error:'Database error'},502);
      if ((await r.json()) !== true) return reply({error:'Profile not found'},404);
      return reply({ok:true});
    }
    if (['list_projects', 'create_project', 'apply_project', 'project_requests', 'decide_request', 'withdraw_request', 'project_chat_list', 'project_chat_send', 'list_my_projects', 'edit_project', 'delete_project', 'leave_project', 'remove_project_member', 'project_chat_report', 'project_chat_react', 'project_group_get', 'project_group_set', 'project_chat_settings_get', 'project_chat_notifications_set', 'project_chat_rules_set', 'match_team'].includes(action)) {
      const uuid = (v) => typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
      const headers = databaseHeaders;
      const rest = supabaseUrl + '/rest/v1/';
      const rest0 = supabaseUrl + '/rest/v1/';
      // The project lookup does not depend on the caller, so both reads run at once.
      const projectLookup = uuid(body.project_id) ? fetch(rest0 + 'eige_projects?id=eq.' + body.project_id + '&select=id,owner_id,title&limit=1', {headers}).catch(() => null) : null;
      const mine = await fetch(baseUrl + '?telegram_id=eq.' + encodeURIComponent(String(user.id)) + '&select=id&limit=1', { headers });
      const dropLookup = () => { if (projectLookup) projectLookup.then(r => { try { r && r.body && r.body.cancel && r.body.cancel().catch(() => {}); } catch (_) {} }).catch(() => {}); };
      if (!mine.ok) { dropLookup(); return reply({error:'Database error'}, 502); }
      const actor = (await mine.json())[0];
      if (!actor || !uuid(actor.id)) { dropLookup(); return reply({error:'Profile not found'}, 404); }
      const validAvatar = v => v === null || v === '' || (typeof v === 'string' && v.length <= 30000 && /^data:image\/jpeg;base64,\/9j\/[A-Za-z0-9+/]+={0,2}$/.test(v));
      const projects = rest + 'eige_projects';
      const requests = rest + 'eige_requests';
      // Notifications are best effort: Telegram may reject them if the user did not start the bot.
      async function notifyProfiles(profileIds, text, excludeChatBlocked = false, chatProjectId = null) {
        try {
          const ids = [...new Set(profileIds.filter(id => uuid(id) && id !== actor.id))];
          if (!ids.length) return;
          for (let start = 0; start < ids.length; start += 100) {
            const slice = ids.slice(start, start + 100);
            const r = await fetch(baseUrl + '?id=in.(' + slice.join(',') + ')&select=id,telegram_id', {headers});
            if (!r.ok) continue;
            const recipients = await r.json();
            let blockedIds=new Set(),mutedProfiles=new Set();
            if(excludeChatBlocked){
              if(!uuid(chatProjectId))continue;
              const muted=await fetch(rest+'eige_chat_notification_preferences?project_id=eq.'+chatProjectId+'&profile_id=in.('+slice.join(',')+')&muted=eq.true&select=profile_id',{headers});
              if(!muted.ok)continue; // Fail closed if preference lookup fails.
              mutedProfiles=new Set((await muted.json()).map(x=>x.profile_id));
              const tgids=recipients.map(x=>x.telegram_id).filter(x=>Number.isSafeInteger(x)&&x>0);
              if(tgids.length){
                const blocked=await fetch(rest+'eige_chat_blocks?telegram_id=in.('+tgids.join(',')+')&select=telegram_id',{headers});
                if(!blocked.ok)continue; // Fail closed: no chat notifications if restriction lookup fails.
                blockedIds=new Set((await blocked.json()).map(x=>x.telegram_id));
              }
            }
            for (let j = 0; j < recipients.length; j += 20) {
              await Promise.all(recipients.slice(j,j+20).map(async recipient => {
                if (!Number.isSafeInteger(recipient.telegram_id) || recipient.telegram_id <= 0 || recipient.telegram_id === user.id || blockedIds.has(recipient.telegram_id) || mutedProfiles.has(recipient.id)) return;
                try {
                  await fetch('https://api.telegram.org/bot' + token + '/sendMessage', {
                    method:'POST', headers:{'Content-Type':'application/json'},
                    body:JSON.stringify({chat_id:recipient.telegram_id,text,disable_notification:false}),
                    signal:AbortSignal.timeout(3000)
                  });
                } catch (_) { /* Do not disclose tokens or make the completed action fail. */ }
              }));
            }
          }
        } catch (_) { /* Delivery failures do not roll back the underlying event. */ }
      }
      const safeTitle = value => typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g,' ').slice(0,70) : 'проект';

      if (action === 'list_projects') {
        const offset = Number.isSafeInteger(body.offset) && body.offset >= 0 && body.offset <= 100000 ? body.offset : 0;
        // Independent reads run concurrently; failure of either still fails the request closed.
        const [r,q] = await Promise.all([
          fetch(projects + '?select=id,owner_id,title,category,description,city,country,avatar_data,wanted_skills&order=created_at.desc&limit=100&offset=' + offset, {headers}),
          fetch(requests + '?sender_id=eq.' + actor.id + '&project_id=not.is.null&select=project_id,status&limit=1000', {headers})
        ]);
        if (!r.ok || !q.ok) return reply({error:'Database error'}, 502);
        const [items,ownRequests] = await Promise.all([r.json(),q.json()]);
        // Only voluntarily published creator profiles are shown in public project lists.
        const ownerIds = [...new Set(items.map(p=>p.owner_id).filter(uuid))];
        let creators = [];
        if (ownerIds.length) {
          const rOwner = await fetch(baseUrl + '?id=in.(' + ownerIds.join(',') + ')&is_listed=eq.true&select=id,name,role,profession,role_verified', {headers});
          if (!rOwner.ok) return reply({error:'Database error'},502);
          creators = await rOwner.json();
        }
        return reply({ok:true, projects:items.map(p => {
          const c = creators.find(x=>x.id===p.owner_id);
          return {id:p.id,title:p.title,category:p.category,description:p.description,city:p.city,country:p.country,avatar_data:null,has_avatar:typeof p.avatar_data === 'string' && p.avatar_data.length > 0,wanted_skills:Array.isArray(p.wanted_skills)?p.wanted_skills:[],is_owner:p.owner_id===actor.id,creator:c ? {name:c.name,role:c.role,profession:c.profession,role_verified:c.role_verified === true} : null,my_request_status:ownRequests.find(x => x.project_id===p.id)?.status || null};
        })});
      }
      if (action === 'list_my_projects') {
        const offset = Number.isSafeInteger(body.offset) && body.offset >= 0 && body.offset <= 100000 ? body.offset : 0;
        const r = await fetch(projects + '?owner_id=eq.' + actor.id + '&select=id,title,category,description,city,country,avatar_data,wanted_skills&order=created_at.desc&limit=100&offset=' + offset, {headers});
        if (!r.ok) return reply({error:'Database error'}, 502);
        const items = await r.json();
        return reply({ok:true, projects:items.map(p => ({...p,is_owner:true}))});
      }
      if (action === 'create_project') {
        const v = body.project;
        if (!v || typeof v !== 'object' || Array.isArray(v)) return reply({error:'Invalid project'},400);
        const clean = {};
        for (const [field,max] of Object.entries({title:70,category:60,description:400,city:50,country:60})) {
          const value = v[field] ?? '';
          if (typeof value !== 'string' || value.length > max) return reply({error:'Invalid project'},400);
          clean[field] = value.trim();
        }
        if (!clean.title || !clean.description || !['Язык и культура','Экология','Предпринимательство','IT','Образование','Другое'].includes(clean.category)) return reply({error:'Invalid project'},400);
        if (!validAvatar(v.avatar_data ?? null)) return reply({error:'Invalid avatar'},400);
        clean.avatar_data = v.avatar_data || null;
        const wantedSkills = normalizeSkills(v.wanted_skills);
        if (wantedSkills === null) return reply({error:'Invalid skills'},400);
        clean.wanted_skills = wantedSkills;
        if (!uuid(body.request_id)) return reply({error:'Invalid request id'},400);
        const r = await fetch(projects + '?on_conflict=client_request_id', {method:'POST',headers:{...headers,'Prefer':'resolution=ignore-duplicates,return=minimal'},body:JSON.stringify({...clean,owner_id:actor.id,client_request_id:body.request_id})});
        if (!r.ok) return reply({error:'Database error'},502);
        const check = await fetch(projects + '?client_request_id=eq.' + body.request_id + '&owner_id=eq.' + actor.id + '&select=id&limit=1', {headers});
        if (!check.ok) return reply({error:'Database error'},502);
        if (!(await check.json()).length) return reply({error:'Invalid request id'},409);
        return reply({ok:true});
      }
      if (!uuid(body.project_id) || !projectLookup) return reply({error:'Invalid project'},400);
      const pr = await projectLookup;
      if (!pr || !pr.ok) return reply({error:'Database error'},502);
      const project = (await pr.json())[0];
      if (!project) return reply({error:'Project not found'},404);
      if (['project_chat_list','project_chat_send','project_chat_report','project_chat_react','project_group_get','project_group_set','project_chat_settings_get','project_chat_notifications_set','project_chat_rules_set'].includes(action)) {
        if (Deno.env.get('EIGE_PROJECT_CHAT_ENABLED') !== 'true') return reply({error:'Chat disabled'},403);
        const rpc = async (name, args) => fetch(rest+'rpc/'+name,{method:'POST',headers,body:JSON.stringify(args)});
        const args={p_telegram_id:user.id,p_project_id:project.id};
        if (['project_chat_settings_get','project_chat_notifications_set','project_chat_rules_set'].includes(action)) {
          if(action==='project_chat_notifications_set' && typeof body.enabled!=='boolean')return reply({error:'Invalid setting'},400);
          if(action==='project_chat_rules_set' && (typeof body.rules!=='string'||body.rules.length>500))return reply({error:'Invalid rules'},400);
          const name=action==='project_chat_settings_get'?'eige_chat_settings_get':action==='project_chat_notifications_set'?'eige_chat_set_notifications':'eige_chat_set_rules';
          const parameters=action==='project_chat_notifications_set'?{...args,p_enabled:body.enabled}:action==='project_chat_rules_set'?{...args,p_rules:body.rules}:args;
          const r=await rpc(name,parameters);if(!r.ok)return reply({error:'Database error'},502);
          const data=await r.json();
          if(data?.error==='forbidden'||data==='forbidden')return reply({error:'Forbidden'},403);
          if(data?.error==='blocked'||data==='blocked')return reply({error:'Chat blocked'},403);
          if(action==='project_chat_settings_get'){if(!data?.ok)return reply({error:'Database error'},502);return reply({ok:true,notifications_enabled:data.notifications_enabled,rules:data.rules});}
          if(data!=='ok')return reply({error:action==='project_chat_rules_set'?'Invalid rules':'Invalid setting'},400);
          return reply({ok:true});
        }
        if (action === 'project_group_get' || action === 'project_group_set') {
          if(action==='project_group_set' && (typeof body.url!=='string'||body.url.length>200))return reply({error:'Invalid group link'},400);
          const r=await rpc(action==='project_group_get'?'eige_project_group_get':'eige_project_group_set',action==='project_group_get'?args:{...args,p_url:body.url.trim()});
          if(!r.ok)return reply({error:'Database error'},502);
          const data=await r.json();
          if(data?.error==='forbidden'||data==='forbidden')return reply({error:'Forbidden'},403);
          if(data?.error==='blocked'||data==='blocked')return reply({error:'Chat blocked'},403);
          if(action==='project_group_get'){if(!data?.ok)return reply({error:'Database error'},502);return reply({ok:true,url:data.url});}
          if(data!=='ok')return reply({error:'Invalid group link'},400);
          return reply({ok:true});
        }
        if (action === 'project_chat_list') {
          const r=await rpc('eige_project_chat_read',args);if(!r.ok)return reply({error:'Database error'},502);
          const data=await r.json();if(data?.error==='blocked')return reply({error:'Chat blocked'},403);if(!data?.ok)return reply({error:'Forbidden'},403);
          return reply({ok:true,messages:data.messages});
        }
        if (action === 'project_chat_send') {
          const text=typeof body.text==='string'?body.text.trim():'';
          if(!text||text.length>500)return reply({error:'Invalid message'},400);
          const isReply=body.reply_to!=null;
          if(isReply&&!uuid(body.reply_to))return reply({error:'Invalid message'},400);
          const r=await rpc(isReply?'eige_project_chat_reply':'eige_project_chat_write',isReply?{...args,p_body:text,p_reply_to:body.reply_to}:{...args,p_body:text});if(!r.ok)return reply({error:'Database error'},502);
          const result=await r.json();
          if(result==='forbidden')return reply({error:'Forbidden'},403);
          if(result==='blocked')return reply({error:'Chat blocked'},403);
          if(result==='rate_limited')return reply({error:'Chat limit'},429);
          if(result==='not_found')return reply({error:'Reply target not found'},404);
          if(result!=='ok')return reply({error:'Invalid message'},400);
          try {const members=await fetch(requests+'?project_id=eq.'+project.id+'&status=eq.approved&select=sender_id&limit=1000',{headers});if(members.ok)await background(notifyProfiles([project.owner_id,...(await members.json()).map(x=>x.sender_id)],'EIGE: новое сообщение в чате проекта «'+safeTitle(project.title)+'».',true,project.id));} catch(_) {}
          return reply({ok:true});
        }
        if (action === 'project_chat_react') {
          if(!uuid(body.message_id)||!['like','heart','laugh','wow','sad','fire'].includes(body.reaction))return reply({error:'Invalid reaction'},400);
          const r=await rpc('eige_chat_toggle_reaction',{...args,p_message_id:body.message_id,p_reaction:body.reaction});
          if(!r.ok)return reply({error:'Database error'},502);
          const result=await r.json();
          if(result==='forbidden')return reply({error:'Forbidden'},403);
          if(result==='blocked')return reply({error:'Chat blocked'},403);
          if(result==='not_found')return reply({error:'Message not found'},404);
          if(result==='rate_limited')return reply({error:'Reaction limit'},429);
          if(result!=='ok')return reply({error:'Invalid reaction'},400);
          return reply({ok:true});
        }
        if(!uuid(body.message_id)||!['spam','unsafe','inappropriate','other'].includes(body.reason))return reply({error:'Invalid report'},400);
        const r=await rpc('eige_report_chat_message',{...args,p_message_id:body.message_id,p_reason:body.reason});if(!r.ok)return reply({error:'Database error'},502);
        const result=await r.json();
        if(result==='forbidden')return reply({error:'Forbidden'},403);
        if(result==='blocked')return reply({error:'Chat blocked'},403);
        if(result==='own_target')return reply({error:'Own target'},400);
        if(result==='not_found')return reply({error:'Report target not found'},404);
        if(result==='rate_limited')return reply({error:'Report limit'},429);
        if(result!=='ok')return reply({error:'Invalid report'},400);
        await background(notifyModerators());
        return reply({ok:true});
      }
      if (action === 'apply_project') {
        if (project.owner_id === actor.id) return reply({error:'Own project'},400);
        const r = await fetch(requests, {method:'POST',headers:{...headers,'Prefer':'return=minimal'},body:JSON.stringify({project_id:project.id,sender_id:actor.id,status:'pending'})});
        if (r.status === 409) return reply({error:'Already applied'},409);
        if (!r.ok) return reply({error:'Database error'},502);
        await background(notifyProfiles([project.owner_id], 'EIGE: новая заявка на участие в проекте «' + safeTitle(project.title) + '». Откройте проект, чтобы её рассмотреть.'));
        return reply({ok:true});
      }
      if (action === 'leave_project') {
        if (project.owner_id === actor.id) return reply({error:'Own project'},400);
        const r = await fetch(requests + '?project_id=eq.' + project.id + '&sender_id=eq.' + actor.id + '&status=eq.approved&select=id', {method:'DELETE',headers:{...headers,'Prefer':'return=representation'}});
        if (!r.ok) return reply({error:'Database error'},502);
        if (!(await r.json()).length) return reply({error:'Not a member'},404);
        return reply({ok:true});
      }
      if (action === 'remove_project_member') {
        if (project.owner_id !== actor.id) return reply({error:'Forbidden'},403);
        if (!uuid(body.request_id)) return reply({error:'Invalid request'},400);
        const r = await fetch(requests + '?id=eq.' + body.request_id + '&project_id=eq.' + project.id + '&status=eq.approved&select=id', {method:'DELETE',headers:{...headers,'Prefer':'return=representation'}});
        if (!r.ok) return reply({error:'Database error'},502);
        if (!(await r.json()).length) return reply({error:'Not a member'},404);
        return reply({ok:true});
      }
      if (action === 'withdraw_request') {
        const query = '?project_id=eq.' + project.id + '&sender_id=eq.' + actor.id + '&status=eq.pending&select=id';
        const r = await fetch(requests + query, {method:'DELETE',headers:{...headers,'Prefer':'return=representation'}});
        if (!r.ok) return reply({error:'Database error'},502);
        const rows = await r.json();
        if (!rows.length) return reply({error:'Request not pending'},404);
        return reply({ok:true});
      }
      if (action === 'edit_project' || action === 'delete_project') {
        if (project.owner_id !== actor.id) return reply({error:'Forbidden'},403);
        if (action === 'delete_project') {
          const r = await fetch(rest + 'rpc/eige_delete_owned_project', {method:'POST',headers,body:JSON.stringify({p_project_id:project.id,p_owner_id:actor.id})});
          if (!r.ok) return reply({error:'Database error'},502);
          if (!(await r.json())) return reply({error:'Project not found'},404);
          return reply({ok:true});
        }
        const v = body.project;
        if (!v || typeof v !== 'object' || Array.isArray(v)) return reply({error:'Invalid project'},400);
        const clean = {};
        for (const [field,max] of Object.entries({title:70,category:60,description:400,city:50,country:60})) {
          const value=v[field] ?? '';
          if (typeof value !== 'string' || value.length > max) return reply({error:'Invalid project'},400);
          clean[field]=value.trim();
        }
        if (!clean.title || !clean.description || !['Язык и культура','Экология','Предпринимательство','IT','Образование','Другое'].includes(clean.category)) return reply({error:'Invalid project'},400);
        if ('avatar_data' in v) {
          if (!validAvatar(v.avatar_data)) return reply({error:'Invalid avatar'},400);
          clean.avatar_data = v.avatar_data || null;
        }
        if ('wanted_skills' in v) {
          const wantedSkills = normalizeSkills(v.wanted_skills);
          if (wantedSkills === null) return reply({error:'Invalid skills'},400);
          clean.wanted_skills = wantedSkills;
        }
        const r = await fetch(projects + '?id=eq.' + project.id + '&owner_id=eq.' + actor.id + '&select=id', {method:'PATCH',headers:{...headers,'Prefer':'return=representation'},body:JSON.stringify(clean)});
        if (!r.ok) return reply({error:'Database error'},502);
        if (!(await r.json()).length) return reply({error:'Project not found'},404);
        return reply({ok:true});
      }
      if (project.owner_id !== actor.id) return reply({error:'Forbidden'},403);
      if (action === 'match_team') {
        // Only the project owner can search; the database returns only voluntarily listed profiles.
        const wanted = body.skills === undefined ? null : normalizeSkills(body.skills);
        if (wanted === null && body.skills !== undefined) return reply({error:'Invalid skills'},400);
        const r = await fetch(rest + 'rpc/eige_match_team', {method:'POST',headers,body:JSON.stringify({p_telegram_id:user.id,p_project_id:project.id,p_skills:wanted})});
        if (!r.ok) return reply({error:'Database error'},502);
        const data = await r.json();
        if (!data?.ok) return reply({error:data?.error === 'forbidden' ? 'Forbidden' : 'Database error'}, data?.error === 'forbidden' ? 403 : 502);
        const matches = Array.isArray(data.matches) ? data.matches : [];
        return reply({ok:true, skills:Array.isArray(data.skills)?data.skills:[], matches:matches.map(p => ({id:p.id,name:p.name,role:p.role,profession:p.profession,interests:p.interests,availability:p.availability,role_verified:p.role_verified === true,city:p.city ?? null,country:p.country ?? null,avatar_data:p.avatar_data ?? null,telegram_username:typeof p.telegram_username === 'string' && /^[A-Za-z0-9_]{5,32}$/.test(p.telegram_username) ? p.telegram_username : null,skills:Array.isArray(p.skills)?p.skills:[],matched:Array.isArray(p.matched)?p.matched:[],total:Number.isSafeInteger(p.total)?p.total:0,relation:['pending','approved','rejected'].includes(p.relation)?p.relation:null}))});
      }
      if (action === 'project_requests') {
        const r = await fetch(requests + '?project_id=eq.' + project.id + '&select=id,sender_id,status&order=created_at.desc&limit=100', {headers});
        if (!r.ok) return reply({error:'Database error'},502);
        const rows = await r.json();
        const ids = [...new Set(rows.map(x=>x.sender_id).filter(uuid))];
        let people = [];
        if (ids.length) {
          const rr = await fetch(baseUrl + '?id=in.(' + ids.join(',') + ')&select=id,name,role,role_verified', {headers});
          if (!rr.ok) return reply({error:'Database error'},502);
          people = await rr.json();
        }
        return reply({ok:true, requests:rows.map(x=>({id:x.id,status:x.status,name:people.find(p=>p.id===x.sender_id)?.name || 'Участник',role:people.find(p=>p.id===x.sender_id)?.role || '',role_verified:people.find(p=>p.id===x.sender_id)?.role_verified === true}))});
      }
      if (action === 'decide_request') {
        if (!uuid(body.request_id) || !['approved','rejected'].includes(body.decision)) return reply({error:'Invalid decision'},400);
        const query = '?id=eq.' + body.request_id + '&project_id=eq.' + project.id + '&status=eq.pending&select=id,status,sender_id';
        const r = await fetch(requests + query, {method:'PATCH',headers:{...headers,'Prefer':'return=representation'},body:JSON.stringify({status:body.decision})});
        if (!r.ok) return reply({error:'Database error'},502);
        const rows = await r.json();
        if (!rows.length) return reply({error:'Request not found or already decided'},404);
        await background(notifyProfiles([rows[0].sender_id], 'EIGE: вашу заявку в проект «' + safeTitle(project.title) + '» ' + (body.decision === 'approved' ? 'приняли' : 'отклонили') + '.'));
        return reply({ok:true});
      }
    }
    if (action === 'avatars') {
      const uuidList = (v) => Array.isArray(v) ? [...new Set(v.filter(x => typeof x === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(x)))].slice(0, 100) : [];
      const profileIds = uuidList(body.profile_ids), projectIds = uuidList(body.project_ids);
      const [pr, jr] = await Promise.all([
        profileIds.length ? fetch(baseUrl + '?id=in.(' + profileIds.join(',') + ')&is_listed=eq.true&show_avatar=eq.true&select=id,avatar_data', {headers:databaseHeaders}) : null,
        projectIds.length ? fetch(supabaseUrl + '/rest/v1/eige_projects?id=in.(' + projectIds.join(',') + ')&select=id,avatar_data', {headers:databaseHeaders}) : null
      ]);
      if ((pr && !pr.ok) || (jr && !jr.ok)) return reply({error:'Database error'},502);
      const pick = async (r) => { const out = {}; if (!r) return out; for (const row of await r.json()) if (typeof row.avatar_data === 'string' && row.avatar_data) out[row.id] = row.avatar_data; return out; };
      return reply({ok:true, profiles:await pick(pr), projects:await pick(jr)});
    }
    const fields = 'name,role,city,country,profession,interests,about,goal,availability,is_listed,show_city,show_country,show_telegram,avatar_data,show_avatar,role_verified,skills';
    if (action === 'list_profiles') {
      // Only these fields are shared, and only for voluntarily listed profiles.
      const offset = Number.isSafeInteger(body.offset) && body.offset >= 0 && body.offset <= 100000 ? body.offset : 0;
      const query = '?is_listed=eq.true&telegram_id=neq.' + encodeURIComponent(String(user.id)) + '&select=id,name,role,profession,interests,availability,role_verified,city,country,show_city,show_country,show_telegram,telegram_username,avatar_data,show_avatar,skills&order=created_at.desc&limit=100&offset=' + offset;
      const result = await fetch(baseUrl + query, { headers: databaseHeaders });
      if (!result.ok) return reply({ error: 'Database error' }, 502);
      const rows = await result.json();
      return reply({ ok: true, profiles: rows.map(p => ({id:p.id,name:p.name,role:p.role,profession:p.profession,interests:p.interests,availability:p.availability,role_verified:p.role_verified === true,skills:Array.isArray(p.skills)?p.skills:[],city:p.show_city ? p.city : null,country:p.show_country ? p.country : null,avatar_data:null,has_avatar:p.show_avatar === true && typeof p.avatar_data === 'string' && p.avatar_data.length > 0,telegram_username:p.show_telegram && /^[A-Za-z0-9_]{5,32}$/.test(p.telegram_username || '') ? p.telegram_username : null})) });
    }
    if (action === 'set_status') {
      if (!['Не указан', 'Готов помочь', 'Работаю над проектом', 'Ищу команду', 'Занят'].includes(body.status)) return reply({ error: 'Invalid status' }, 400);
      const query = '?telegram_id=eq.' + encodeURIComponent(String(user.id)) + '&select=availability';
      const result = await fetch(baseUrl + query, {
        method: 'PATCH', headers: { ...databaseHeaders, 'Prefer': 'return=representation' },
        body: JSON.stringify({ availability: body.status })
      });
      if (!result.ok) return reply({ error: 'Database error' }, 502);
      const rows = await result.json();
      if (!rows.length) return reply({ error: 'Profile not found' }, 404);
      return reply({ ok: true, status: rows[0].availability });
    }
    if (action === 'set_visibility') {
      if (typeof body.visible !== 'boolean' || typeof body.show_city !== 'boolean' || typeof body.show_telegram !== 'boolean') return reply({ error: 'Invalid visibility' }, 400);
      const username = typeof user.username === 'string' && /^[A-Za-z0-9_]{5,32}$/.test(user.username) ? user.username : null;
      if (body.show_telegram && !username) return reply({ error: 'Telegram username missing' }, 400);
      const query = '?telegram_id=eq.' + encodeURIComponent(String(user.id)) + '&select=is_listed,show_city,show_country,show_telegram,show_avatar';
      const result = await fetch(baseUrl + query, {
        method: 'PATCH',
        headers: { ...databaseHeaders, 'Prefer': 'return=representation' },
        body: JSON.stringify({ is_listed: body.visible, show_city: body.show_city, show_telegram: body.show_telegram, telegram_username: body.show_telegram ? username : null, ...(typeof body.show_avatar === 'boolean' ? {show_avatar:body.show_avatar} : {}), ...(typeof body.show_country === 'boolean' ? {show_country:body.show_country} : {}) })
      });
      if (!result.ok) return reply({ error: 'Database error' }, 502);
      const rows = await result.json();
      if (!rows.length) return reply({ error: 'Profile not found' }, 404);
      return reply({ ok: true, visible: rows[0].is_listed, show_city: rows[0].show_city, show_country: rows[0].show_country, show_telegram: rows[0].show_telegram, show_avatar: rows[0].show_avatar });
    }
    if (action === 'get_profile') {
      const query = '?telegram_id=eq.' + encodeURIComponent(String(user.id)) + '&select=' + fields + '&limit=1';
      const result = await fetch(baseUrl + query, { headers: databaseHeaders });
      if (!result.ok) return reply({ error: 'Database error' }, 502);
      const rows = await result.json();
      return reply({ ok: true, profile: rows[0] || null });
    }
    const p = body.profile;
    if (!p || typeof p !== 'object' || Array.isArray(p)) return reply({ error: 'Invalid profile' }, 400);
    const limits = { name: 70, role: 50, city: 60, country: 60, profession: 90, interests: 120, about: 400, goal: 140 };
    const clean = {};
    for (const [field, max] of Object.entries(limits)) {
      const value = p[field] ?? '';
      if (typeof value !== 'string' || value.length > max) return reply({ error: 'Invalid profile' }, 400);
      clean[field] = value.trim();
    }
    if (!clean.name || !['Ученик','Выпускник','Педагог','Специалист / предприниматель'].includes(clean.role)) {
      return reply({ error: 'Invalid profile' }, 400);
    }
    if ('avatar_data' in p) {
      const v = p.avatar_data;
      if (!(v === null || v === '' || (typeof v === 'string' && v.length <= 30000 && /^data:image\/jpeg;base64,\/9j\/[A-Za-z0-9+/]+={0,2}$/.test(v)))) return reply({error:'Invalid avatar'},400);
      clean.avatar_data = v || null;
    }
    if ('skills' in p) {
      const skills = normalizeSkills(p.skills);
      if (skills === null) return reply({error:'Invalid skills'},400);
      clean.skills = skills;
    }
    const result = await fetch(baseUrl + '?on_conflict=telegram_id&select=' + fields, {
      method: 'POST',
      headers: { ...databaseHeaders, 'Prefer': 'resolution=merge-duplicates,return=representation' },
      body: JSON.stringify({ ...clean, telegram_id: user.id })
    });
    if (!result.ok) return reply({ error: 'Database error' }, 502);
    const rows = await result.json();
    return reply({ ok: true, profile: rows[0] });
  } catch (_) {
    return reply({ error: 'Invalid request' }, 400);
  }
});
