-- Базовая структура для НОВОГО проекта Supabase.
-- Для существующей базы: сначала сделать резервную копию и проверить схему.
create table if not exists public.eige_profiles (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint unique not null,
  name text not null,
  role text not null,
  city text,
  profession text,
  interests text,
  about text,
  goal text,
  created_at timestamptz default now()
);
create table if not exists public.eige_projects (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.eige_profiles(id),
  title text not null,
  category text not null,
  description text not null,
  city text,
  created_at timestamptz default now()
);
create table if not exists public.eige_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.eige_profiles(id),
  recipient_id uuid references public.eige_profiles(id),
  project_id uuid references public.eige_projects(id),
  created_at timestamptz default now(),
  check ((recipient_id is not null and project_id is null)
      or (recipient_id is null and project_id is not null))
);
alter table public.eige_profiles enable row level security;
alter table public.eige_projects enable row level security;
alter table public.eige_requests enable row level security;
revoke all on public.eige_profiles, public.eige_projects, public.eige_requests from public, anon, authenticated;
grant all on public.eige_profiles, public.eige_projects, public.eige_requests to service_role;
