begin;
-- Жалобы содержат категорию, но не свободный текст или вложения.
create table if not exists public.eige_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.eige_profiles(id) on delete cascade,
  target_kind text not null check (target_kind in ('profile','project')),
  target_id uuid not null,
  reason text not null check (reason in ('spam','unsafe','inappropriate','other')),
  status text not null default 'open' check (status in ('open','reviewed')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);
create index if not exists eige_reports_open on public.eige_reports(status,created_at desc);
create table if not exists public.eige_report_rate_limit (
  telegram_id bigint primary key,
  window_started timestamptz not null default now(),
  attempts integer not null default 0
);
alter table public.eige_reports enable row level security;
alter table public.eige_report_rate_limit enable row level security;
revoke all on table public.eige_reports, public.eige_report_rate_limit from public, anon, authenticated;
grant all on table public.eige_reports, public.eige_report_rate_limit to service_role;

-- Получатель жалобы и количество попыток определяются на сервере; прямая выдача RPC запрещена.
create or replace function public.eige_create_report(p_telegram_id bigint,p_target_kind text,p_target_id uuid,p_reason text)
returns text language plpgsql security invoker set search_path=public,pg_temp as $$
declare reporter uuid; project_owner uuid; n integer;
begin
  select id into reporter from public.eige_profiles where telegram_id=p_telegram_id for key share;
  if reporter is null then return 'no_profile'; end if;
  if p_target_kind is null or p_target_kind not in ('profile','project') or p_reason is null or p_reason not in ('spam','unsafe','inappropriate','other') or p_target_id is null then return 'invalid'; end if;
  if p_target_kind='profile' then
    if p_target_id=reporter then return 'own_target'; end if;
    perform 1 from public.eige_profiles where id=p_target_id and is_listed=true for key share;
    if not found then return 'not_found'; end if;
  else
    select owner_id into project_owner from public.eige_projects where id=p_target_id for key share;
    if not found then return 'not_found'; end if;
    if project_owner=reporter then return 'own_target'; end if;
  end if;
  insert into public.eige_report_rate_limit(telegram_id,window_started,attempts)
    values(p_telegram_id,now(),1)
  on conflict (telegram_id) do update set
    attempts=case when eige_report_rate_limit.window_started <= now()-interval '15 minutes' then 1 else least(eige_report_rate_limit.attempts+1,6) end,
    window_started=case when eige_report_rate_limit.window_started <= now()-interval '15 minutes' then now() else eige_report_rate_limit.window_started end
  returning attempts into n;
  if n>5 then return 'rate_limited'; end if;
  insert into public.eige_reports(reporter_id,target_kind,target_id,reason) values(reporter,p_target_kind,p_target_id,p_reason);
  return 'ok';
end $$;

-- Закрытие означает только «просмотрено», а не подтверждение или решение по существу.
create or replace function public.eige_admin_review_report(p_report_id uuid,p_actor_telegram_id bigint)
returns boolean language plpgsql security invoker set search_path=public,pg_temp as $$
begin
  update public.eige_reports set status='reviewed', reviewed_at=now() where id=p_report_id and status='open';
  if not found then return false; end if;
  insert into public.eige_admin_audit(actor_telegram_id,action,target_id) values(p_actor_telegram_id,'review_report',p_report_id);
  return true;
end $$;
revoke all on function public.eige_create_report(bigint,text,uuid,text) from public, anon, authenticated;
revoke all on function public.eige_admin_review_report(uuid,bigint) from public, anon, authenticated;
grant execute on function public.eige_create_report(bigint,text,uuid,text) to service_role;
grant execute on function public.eige_admin_review_report(uuid,bigint) to service_role;

-- При удалении проекта вместе с ним удаляются и жалобы на этот проект.
create or replace function public.eige_delete_owned_project(p_project_id uuid,p_owner_id uuid)
returns boolean language plpgsql security invoker set search_path=public,pg_temp as $$
begin
  perform 1 from public.eige_projects where id=p_project_id and owner_id=p_owner_id for update;
  if not found then return false; end if;
  delete from public.eige_reports where target_kind='project' and target_id=p_project_id;
  delete from public.eige_project_messages where project_id=p_project_id;
  delete from public.eige_requests where project_id=p_project_id;
  delete from public.eige_projects where id=p_project_id and owner_id=p_owner_id;
  return found;
end $$;
revoke all on function public.eige_delete_owned_project(uuid,uuid) from public, anon, authenticated;
grant execute on function public.eige_delete_owned_project(uuid,uuid) to service_role;

-- Удаление аккаунта удаляет и отправленные им жалобы, и жалобы на его анкету.
create or replace function public.eige_delete_my_account(p_telegram_id bigint)
returns boolean language plpgsql security invoker set search_path=public,pg_temp as $$
declare profile_id uuid; project record; ok boolean;
begin
  select id into profile_id from public.eige_profiles where telegram_id=p_telegram_id for update;
  if not found then return false; end if;
  for project in select id from public.eige_projects where owner_id=profile_id loop
    select public.eige_delete_owned_project(project.id,profile_id) into ok;
    if not ok then raise exception 'project deletion failed'; end if;
  end loop;
  delete from public.eige_reports where reporter_id=profile_id or (target_kind='profile' and target_id=profile_id);
  delete from public.eige_project_messages where sender_id=profile_id;
  delete from public.eige_requests where sender_id=profile_id or recipient_id=profile_id;
  delete from public.eige_profiles where id=profile_id;
  return found;
end $$;

create or replace function public.eige_admin_delete_profile(p_profile_id uuid,p_actor_telegram_id bigint)
returns boolean language plpgsql security invoker set search_path=public,pg_temp as $$
declare target_telegram_id bigint; project record; ok boolean;
begin
  select telegram_id into target_telegram_id from public.eige_profiles where id=p_profile_id for update;
  if not found or target_telegram_id=p_actor_telegram_id then return false; end if;
  for project in select id from public.eige_projects where owner_id=p_profile_id loop
    select public.eige_delete_owned_project(project.id,p_profile_id) into ok;
    if not ok then raise exception 'project deletion failed'; end if;
  end loop;
  delete from public.eige_reports where reporter_id=p_profile_id or (target_kind='profile' and target_id=p_profile_id);
  delete from public.eige_project_messages where sender_id=p_profile_id;
  delete from public.eige_requests where sender_id=p_profile_id or recipient_id=p_profile_id;
  delete from public.eige_profiles where id=p_profile_id;
  if not found then return false; end if;
  insert into public.eige_admin_audit(actor_telegram_id,action,target_id) values(p_actor_telegram_id,'delete_profile',p_profile_id);
  return true;
end $$;
revoke all on function public.eige_delete_my_account(bigint), public.eige_admin_delete_profile(uuid,bigint) from public, anon, authenticated;
grant execute on function public.eige_delete_my_account(bigint), public.eige_admin_delete_profile(uuid,bigint) to service_role;
commit;
