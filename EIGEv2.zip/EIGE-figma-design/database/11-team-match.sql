-- 11. Подбор команды: навыки участников и навыки, нужные проекту.
-- Запускать один раз после 01–10. Существующие данные не удаляются.
begin;

alter table public.eige_profiles add column if not exists skills text[] not null default '{}';
alter table public.eige_projects add column if not exists wanted_skills text[] not null default '{}';

-- Навыки — короткие нормализованные строки; не больше 20 на анкету или проект.
alter table public.eige_profiles drop constraint if exists eige_profiles_skills_limit;
alter table public.eige_profiles add constraint eige_profiles_skills_limit check (cardinality(skills) <= 20);
alter table public.eige_projects drop constraint if exists eige_projects_wanted_skills_limit;
alter table public.eige_projects add constraint eige_projects_wanted_skills_limit check (cardinality(wanted_skills) <= 20);

create index if not exists eige_profiles_skills_gin on public.eige_profiles using gin (skills);

-- Прямой доступ клиентских ролей к новым полям запрещён; работает только сервер.
revoke all (skills) on table public.eige_profiles from public, anon, authenticated;
revoke all (wanted_skills) on table public.eige_projects from public, anon, authenticated;

-- Нормализация: нижний регистр, обрезка пробелов, без пустых и повторов, не длиннее 30 символов, не больше 20 штук.
create or replace function public.eige_normalize_skills(p_skills text[])
returns text[] language sql immutable set search_path = public, pg_temp as $$
  select coalesce(array(
    select s from (
      select distinct on (s) s, ord from (
        select lower(regexp_replace(btrim(x), '\s+', ' ', 'g')) as s, ord
        from unnest(coalesce(p_skills, '{}')) with ordinality as u(x, ord)
      ) raw
      where s <> '' and length(s) <= 30
      order by s, ord
    ) uniq
    order by ord
    limit 20
  ), '{}');
$$;

-- Подбор: только создатель проекта, только добровольно опубликованные анкеты, без своей анкеты.
-- Возвращаются те же поля, что и в общем списке людей (приватность города, страны, аватара, юзернейма сохраняется).
create or replace function public.eige_match_team(p_telegram_id bigint, p_project_id uuid, p_skills text[])
returns jsonb language plpgsql security invoker set search_path = public, pg_temp as $$
declare owner uuid; wanted text[]; matches jsonb;
begin
  select id into owner from public.eige_profiles where telegram_id = p_telegram_id;
  if owner is null then return jsonb_build_object('ok', false, 'error', 'no_profile'); end if;
  select public.eige_normalize_skills(coalesce(p_skills, wanted_skills)) into wanted
    from public.eige_projects where id = p_project_id and owner_id = owner;
  if not found then return jsonb_build_object('ok', false, 'error', 'forbidden'); end if;
  if cardinality(wanted) = 0 then return jsonb_build_object('ok', true, 'skills', wanted, 'matches', '[]'::jsonb); end if;

  select coalesce(jsonb_agg(item order by score desc, created_at desc), '[]'::jsonb) into matches from (
    select p.created_at, cardinality(m.matched) as score,
      jsonb_build_object(
        'id', p.id, 'name', p.name, 'role', p.role, 'profession', p.profession, 'interests', p.interests,
        'availability', p.availability, 'role_verified', p.role_verified is true,
        'city', case when p.show_city then p.city end,
        'country', case when p.show_country then p.country end,
        'avatar_data', case when p.show_avatar then p.avatar_data end,
        'telegram_username', case when p.show_telegram and coalesce(p.telegram_username, '') ~ '^[A-Za-z0-9_]{5,32}$' then p.telegram_username end,
        'skills', to_jsonb(p.skills), 'matched', to_jsonb(m.matched), 'total', cardinality(wanted),
        'relation', (select r.status from public.eige_requests r where r.project_id = p_project_id and r.sender_id = p.id order by r.created_at desc limit 1)
      ) as item
    from public.eige_profiles p
    cross join lateral (select array(select s from unnest(p.skills) s where s = any(wanted) order by s) as matched) m
    where p.is_listed = true and p.id <> owner and cardinality(m.matched) > 0
    order by cardinality(m.matched) desc, p.created_at desc
    limit 50
  ) t;
  return jsonb_build_object('ok', true, 'skills', wanted, 'matches', matches);
end $$;

revoke all on function public.eige_normalize_skills(text[]) from public, anon, authenticated;
revoke all on function public.eige_match_team(bigint, uuid, text[]) from public, anon, authenticated;
grant execute on function public.eige_normalize_skills(text[]) to service_role;
grant execute on function public.eige_match_team(bigint, uuid, text[]) to service_role;

commit;
