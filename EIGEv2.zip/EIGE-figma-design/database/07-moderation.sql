begin;
-- Заблокированный участник не читает чат; блокировка синхронизируется с действиями модератора.
create or replace function public.eige_project_chat_read(p_telegram_id bigint,p_project_id uuid)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; result jsonb;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return jsonb_build_object('error','forbidden'); end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return jsonb_build_object('error','blocked'); end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',q.id,'name',q.name,'text',q.body,'created_at',q.created_at,'mine',q.sender_id=actor) order by q.created_at,q.id),'[]'::jsonb) into result
 from (select m.id,m.sender_id,m.body,m.created_at,p.name from public.eige_project_messages m
       join public.eige_profiles p on p.id=m.sender_id where m.project_id=p_project_id
       order by m.created_at desc,m.id desc limit 100) q;
 return jsonb_build_object('ok',true,'messages',result);
end $$;

create or replace function public.eige_report_chat_message(p_telegram_id bigint,p_project_id uuid,p_message_id uuid,p_reason text)
returns text language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; sender uuid; n integer;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return 'forbidden'; end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return 'blocked'; end if;
 if p_reason is null or p_reason not in ('spam','unsafe','inappropriate','other') then return 'invalid'; end if;
 select sender_id into sender from public.eige_project_messages where id=p_message_id and project_id=p_project_id for key share;
 if not found then return 'not_found'; end if;
 if sender=actor then return 'own_target'; end if;
 insert into public.eige_report_rate_limit(telegram_id,window_started,attempts) values(p_telegram_id,now(),1)
 on conflict (telegram_id) do update set
 attempts=case when eige_report_rate_limit.window_started<=now()-interval '15 minutes' then 1 else least(eige_report_rate_limit.attempts+1,6) end,
 window_started=case when eige_report_rate_limit.window_started<=now()-interval '15 minutes' then now() else eige_report_rate_limit.window_started end returning attempts into n;
 if n>5 then return 'rate_limited'; end if;
 insert into public.eige_chat_reports(message_id,reporter_id,reason) values(p_message_id,actor,p_reason);
 return 'ok';
end $$;

-- После просмотра модератор по-прежнему может удалить сообщение или ограничить автора.
create or replace function public.eige_admin_handle_chat_report(p_report_id uuid,p_action text,p_actor_telegram_id bigint)
returns boolean language plpgsql security invoker set search_path=public,pg_temp as $$
declare msg uuid; sender_tg bigint;
begin
 if p_action is null or p_action not in ('review','delete','block') then return false; end if;
 select message_id into msg from public.eige_chat_reports where id=p_report_id;
 if not found then return false; end if;
 -- Serialize moderation actions on reports about the same message before locking any report row.
 perform pg_advisory_xact_lock(hashtextextended('eige-chat-message:'||msg::text,0));
 perform 1 from public.eige_chat_reports where id=p_report_id and (status='open' or (status='reviewed' and p_action in ('delete','block'))) for update;
 if not found then return false; end if;
 if p_action='review' then
   update public.eige_chat_reports set status='reviewed',reviewed_at=now() where id=p_report_id;
 else
   select p.telegram_id into sender_tg from public.eige_project_messages m join public.eige_profiles p on p.id=m.sender_id where m.id=msg;
   if not found then return false; end if;
   if p_action='block' then
     if sender_tg=p_actor_telegram_id then return false; end if;
     -- Same lock order as the chat reader, sender and reporter: advisory lock before message row.
     perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||sender_tg::text,0));
   end if;
   perform 1 from public.eige_project_messages where id=msg for update;
   if not found then return false; end if;
   if p_action='block' then
     insert into public.eige_chat_blocks(telegram_id) values(sender_tg) on conflict(telegram_id) do nothing;
   end if;
   delete from public.eige_project_messages where id=msg;
 end if;
 insert into public.eige_admin_audit(actor_telegram_id,action,target_id) values(p_actor_telegram_id,'chat_report_'||p_action,msg);
 return true;
end $$;
revoke all on function public.eige_project_chat_read(bigint,uuid), public.eige_report_chat_message(bigint,uuid,uuid,text), public.eige_admin_handle_chat_report(uuid,text,bigint) from public,anon,authenticated;
grant execute on function public.eige_project_chat_read(bigint,uuid), public.eige_report_chat_message(bigint,uuid,uuid,text), public.eige_admin_handle_chat_report(uuid,text,bigint) to service_role;
commit;
