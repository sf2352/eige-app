begin;
-- Missing preference means notifications are enabled, preserving previous behaviour.
create table if not exists public.eige_chat_notification_preferences (
 project_id uuid not null references public.eige_projects(id) on delete cascade,
 profile_id uuid not null references public.eige_profiles(id) on delete cascade,
 muted boolean not null default false,
 updated_at timestamptz not null default now(),
 primary key(project_id,profile_id)
);
create index if not exists eige_chat_notification_pref_profile on public.eige_chat_notification_preferences(profile_id);
create table if not exists public.eige_chat_rules (
 project_id uuid primary key references public.eige_projects(id) on delete cascade,
 body text not null default '' check(char_length(body)<=500),
 updated_at timestamptz not null default now()
);
alter table public.eige_chat_notification_preferences enable row level security;
alter table public.eige_chat_rules enable row level security;
revoke all on table public.eige_chat_notification_preferences,public.eige_chat_rules from public,anon,authenticated;
grant all on table public.eige_chat_notification_preferences,public.eige_chat_rules to service_role;

create or replace function public.eige_chat_settings_get(p_telegram_id bigint,p_project_id uuid)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; muted boolean; rules text;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return jsonb_build_object('error','forbidden'); end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return jsonb_build_object('error','blocked'); end if;
 select p.muted into muted from public.eige_chat_notification_preferences p where p.project_id=p_project_id and p.profile_id=actor;
 select r.body into rules from public.eige_chat_rules r where r.project_id=p_project_id;
 return jsonb_build_object('ok',true,'notifications_enabled',not coalesce(muted,false),'rules',coalesce(rules,''));
end $$;

create or replace function public.eige_chat_set_notifications(p_telegram_id bigint,p_project_id uuid,p_enabled boolean)
returns text language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return 'forbidden'; end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return 'blocked'; end if;
 if p_enabled is null then return 'invalid'; end if;
 insert into public.eige_chat_notification_preferences(project_id,profile_id,muted) values(p_project_id,actor,not p_enabled)
 on conflict(project_id,profile_id) do update set muted=excluded.muted,updated_at=now();
 return 'ok';
end $$;

create or replace function public.eige_chat_set_rules(p_telegram_id bigint,p_project_id uuid,p_rules text)
returns text language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; owner_id uuid;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return 'forbidden'; end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return 'blocked'; end if;
 select p.owner_id into owner_id from public.eige_projects p where p.id=p_project_id;
 if owner_id is distinct from actor then return 'forbidden'; end if;
 if p_rules is null or char_length(p_rules)>500 then return 'invalid'; end if;
 insert into public.eige_chat_rules(project_id,body) values(p_project_id,trim(p_rules))
 on conflict(project_id) do update set body=excluded.body,updated_at=now();
 return 'ok';
end $$;
revoke all on function public.eige_chat_settings_get(bigint,uuid),public.eige_chat_set_notifications(bigint,uuid,boolean),public.eige_chat_set_rules(bigint,uuid,text) from public,anon,authenticated;
grant execute on function public.eige_chat_settings_get(bigint,uuid),public.eige_chat_set_notifications(bigint,uuid,boolean),public.eige_chat_set_rules(bigint,uuid,text) to service_role;
commit;
