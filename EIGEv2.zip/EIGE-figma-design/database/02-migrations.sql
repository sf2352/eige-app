-- Новые и существующие анкеты скрыты, пока владелец не опубликует их.
alter table public.eige_profiles
  add column if not exists is_listed boolean not null default false;

-- Запрет прямого доступа через публичные роли. Сервер применяет собственные проверки.
alter table public.eige_profiles enable row level security;
alter table public.eige_projects enable row level security;
alter table public.eige_requests enable row level security;
revoke all on table public.eige_profiles, public.eige_projects, public.eige_requests
  from public, anon, authenticated;
grant all on table public.eige_profiles, public.eige_projects, public.eige_requests
  to service_role;

-- Статус участника: по умолчанию не указан.
alter table public.eige_profiles
  add column if not exists availability text not null default 'Не указан';
-- Добавляет статусы заявок на проекты, не удаляя существующие данные.
alter table public.eige_requests
  add column if not exists status text not null default 'pending';

-- Один пользователь может отправить не более одной заявки в проект.
create unique index if not exists eige_one_request_per_project
  on public.eige_requests (project_id, sender_id)
  where project_id is not null;

alter table public.eige_profiles enable row level security;
alter table public.eige_projects enable row level security;
alter table public.eige_requests enable row level security;
revoke all on table public.eige_profiles, public.eige_projects, public.eige_requests
  from public, anon, authenticated;
grant all on table public.eige_profiles, public.eige_projects, public.eige_requests
  to service_role;
-- Защита от повторного создания проекта при повторной отправке формы.
alter table public.eige_projects add column if not exists client_request_id uuid;
create unique index if not exists eige_project_client_request_unique
  on public.eige_projects (client_request_id);
-- Настройки добровольного показа города и Telegram.
alter table public.eige_profiles add column if not exists show_city boolean not null default false;
alter table public.eige_profiles add column if not exists show_telegram boolean not null default false;
alter table public.eige_profiles add column if not exists telegram_username text;

-- Тестовая таблица групповых сообщений. Доступ только через серверную функцию.
create table if not exists public.eige_project_messages (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.eige_projects(id),
  sender_id uuid not null references public.eige_profiles(id),
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);
create index if not exists eige_project_messages_timeline on public.eige_project_messages (project_id, created_at desc);
alter table public.eige_project_messages enable row level security;
revoke all on table public.eige_project_messages from public, anon, authenticated;
grant all on table public.eige_project_messages to service_role;
-- Небольшие изображения, профиль по умолчанию НЕ публикует аватар.
alter table public.eige_profiles add column if not exists avatar_data text;
alter table public.eige_profiles add column if not exists show_avatar boolean not null default false;
alter table public.eige_projects add column if not exists avatar_data text;

-- Атомарное удаление проекта и зависимых заявок и сообщений.
-- Доступ только серверной роли; проверка владельца выполняется сервером и внутри функции.
create or replace function public.eige_delete_owned_project(p_project_id uuid, p_owner_id uuid)
returns boolean language plpgsql security invoker set search_path = public, pg_temp as $$
begin
  perform 1 from public.eige_projects where id = p_project_id and owner_id = p_owner_id for update;
  if not found then return false; end if;
  delete from public.eige_project_messages where project_id = p_project_id;
  delete from public.eige_requests where project_id = p_project_id;
  delete from public.eige_projects where id = p_project_id and owner_id = p_owner_id;
  return found;
end;
$$;
revoke all on function public.eige_delete_owned_project(uuid, uuid) from public, anon, authenticated;
grant execute on function public.eige_delete_owned_project(uuid, uuid) to service_role;
