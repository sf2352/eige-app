begin;
create table if not exists public.eige_chat_reports (
 id uuid primary key default gen_random_uuid(),
 message_id uuid not null references public.eige_project_messages(id) on delete cascade,
 reporter_id uuid not null references public.eige_profiles(id) on delete cascade,
 reason text not null check(reason in ('spam','unsafe','inappropriate','other')),
 status text not null default 'open' check(status in ('open','reviewed')),
 created_at timestamptz not null default now(),
 reviewed_at timestamptz
);
create index if not exists eige_chat_reports_open on public.eige_chat_reports(status,created_at desc);
create table if not exists public.eige_chat_rate_limit (
 telegram_id bigint primary key,
 window_started timestamptz not null default now(),
 attempts integer not null default 0
);
create table if not exists public.eige_chat_blocks (
 id uuid primary key default gen_random_uuid(),
 telegram_id bigint not null unique,
 created_at timestamptz not null default now()
);
alter table public.eige_chat_reports enable row level security;
alter table public.eige_chat_rate_limit enable row level security;
alter table public.eige_chat_blocks enable row level security;
revoke all on table public.eige_chat_reports,public.eige_chat_rate_limit,public.eige_chat_blocks from public,anon,authenticated;
grant all on table public.eige_chat_reports,public.eige_chat_rate_limit,public.eige_chat_blocks to service_role;

-- Проверка Telegram ID и членства; блокировки строк держатся до конца транзакции.
create or replace function public.eige_chat_actor(p_telegram_id bigint,p_project_id uuid)
returns uuid language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; owner uuid;
begin
 select id into actor from public.eige_profiles where telegram_id=p_telegram_id for key share;
 if actor is null then return null; end if;
 select owner_id into owner from public.eige_projects where id=p_project_id for share;
 if not found then return null; end if;
 if owner<>actor then
   perform 1 from public.eige_requests where project_id=p_project_id and sender_id=actor and status='approved' for share;
   if not found then return null; end if;
 end if;
 return actor;
end $$;

create or replace function public.eige_project_chat_read(p_telegram_id bigint,p_project_id uuid)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; result jsonb;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return jsonb_build_object('error','forbidden'); end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',q.id,'name',q.name,'text',q.body,'created_at',q.created_at,'mine',q.sender_id=actor) order by q.created_at,q.id),'[]'::jsonb) into result
 from (select m.id,m.sender_id,m.body,m.created_at,p.name from public.eige_project_messages m
       join public.eige_profiles p on p.id=m.sender_id where m.project_id=p_project_id
       order by m.created_at desc,m.id desc limit 100) q;
 return jsonb_build_object('ok',true,'messages',result);
end $$;

create or replace function public.eige_project_chat_write(p_telegram_id bigint,p_project_id uuid,p_body text)
returns text language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; n int;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return 'forbidden'; end if;
 if p_body is null or char_length(trim(p_body))<1 or char_length(p_body)>500 then return 'invalid'; end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:' || p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return 'blocked'; end if;
 insert into public.eige_chat_rate_limit(telegram_id,window_started,attempts) values(p_telegram_id,now(),1)
 on conflict(telegram_id) do update set
 attempts=case when eige_chat_rate_limit.window_started<=now()-interval '1 minute' then 1 else least(eige_chat_rate_limit.attempts+1,6) end,
 window_started=case when eige_chat_rate_limit.window_started<=now()-interval '1 minute' then now() else eige_chat_rate_limit.window_started end returning attempts into n;
 if n>5 then return 'rate_limited'; end if;
 insert into public.eige_project_messages(project_id,sender_id,body) values(p_project_id,actor,trim(p_body));
 return 'ok';
end $$;

create or replace function public.eige_report_chat_message(p_telegram_id bigint,p_project_id uuid,p_message_id uuid,p_reason text)
returns text language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; sender uuid; n integer;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return 'forbidden'; end if;
 if p_reason is null or p_reason not in ('spam','unsafe','inappropriate','other') then return 'invalid'; end if;
 select sender_id into sender from public.eige_project_messages where id=p_message_id and project_id=p_project_id for key share;
 if not found then return 'not_found'; end if;
 if sender=actor then return 'own_target'; end if;
 insert into public.eige_report_rate_limit(telegram_id,window_started,attempts) values(p_telegram_id,now(),1)
 on conflict (telegram_id) do update set
 attempts=case when eige_report_rate_limit.window_started<=now()-interval '15 minutes' then 1 else least(eige_report_rate_limit.attempts+1,6) end,
 window_started=case when eige_report_rate_limit.window_started<=now()-interval '15 minutes' then now() else eige_report_rate_limit.window_started end returning attempts into n;
 if n>5 then return 'rate_limited'; end if;
 insert into public.eige_chat_reports(message_id,reporter_id,reason) values(p_message_id,actor,p_reason);
 return 'ok';
end $$;

-- Действия администратора: просмотрено, удалить сообщение или удалить и ограничить отправку автора.
create or replace function public.eige_admin_handle_chat_report(p_report_id uuid,p_action text,p_actor_telegram_id bigint)
returns boolean language plpgsql security invoker set search_path=public,pg_temp as $$
declare msg uuid; sender_tg bigint;
begin
 if p_action is null or p_action not in ('review','delete','block') then return false; end if;
 select message_id into msg from public.eige_chat_reports where id=p_report_id and status='open' for update;
 if not found then return false; end if;
 if p_action='review' then
   update public.eige_chat_reports set status='reviewed',reviewed_at=now() where id=p_report_id;
 else
   select p.telegram_id into sender_tg from public.eige_project_messages m join public.eige_profiles p on p.id=m.sender_id where m.id=msg for update of m;
   if not found then return false; end if;
   if p_action='block' then
     if sender_tg=p_actor_telegram_id then return false; end if;
     perform pg_advisory_xact_lock(hashtextextended('eige-chat:' || sender_tg::text,0));
     insert into public.eige_chat_blocks(telegram_id) values(sender_tg) on conflict(telegram_id) do nothing;
   end if;
   delete from public.eige_project_messages where id=msg;
 end if;
 insert into public.eige_admin_audit(actor_telegram_id,action,target_id) values(p_actor_telegram_id,'chat_report_'||p_action,msg);
 return true;
end $$;

create or replace function public.eige_admin_unblock_chat(p_block_id uuid,p_actor_telegram_id bigint)
returns boolean language plpgsql security invoker set search_path=public,pg_temp as $$
begin
 delete from public.eige_chat_blocks where id=p_block_id;
 if not found then return false; end if;
 insert into public.eige_admin_audit(actor_telegram_id,action,target_id) values(p_actor_telegram_id,'chat_unblock',p_block_id);
 return true;
end $$;

revoke all on function public.eige_chat_actor(bigint,uuid),public.eige_project_chat_read(bigint,uuid),public.eige_project_chat_write(bigint,uuid,text),public.eige_report_chat_message(bigint,uuid,uuid,text),public.eige_admin_handle_chat_report(uuid,text,bigint),public.eige_admin_unblock_chat(uuid,bigint) from public,anon,authenticated;
grant execute on function public.eige_chat_actor(bigint,uuid),public.eige_project_chat_read(bigint,uuid),public.eige_project_chat_write(bigint,uuid,text),public.eige_report_chat_message(bigint,uuid,uuid,text),public.eige_admin_handle_chat_report(uuid,text,bigint),public.eige_admin_unblock_chat(uuid,bigint) to service_role;
commit;
