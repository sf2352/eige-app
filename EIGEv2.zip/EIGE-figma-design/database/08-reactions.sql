begin;
-- Each participant can choose one reaction per message. Reactions are removed with the message or account.
create table if not exists public.eige_chat_reactions (
 message_id uuid not null references public.eige_project_messages(id) on delete cascade,
 actor_id uuid not null references public.eige_profiles(id) on delete cascade,
 reaction text not null check (reaction in ('like','heart','laugh','wow','sad','fire')),
 created_at timestamptz not null default now(),
 primary key(message_id,actor_id)
);
create index if not exists eige_chat_reactions_actor on public.eige_chat_reactions(actor_id);
create table if not exists public.eige_reaction_rate_limit (
 telegram_id bigint primary key,
 window_started timestamptz not null default now(),
 attempts integer not null default 0
);
alter table public.eige_chat_reactions enable row level security;
alter table public.eige_reaction_rate_limit enable row level security;
revoke all on table public.eige_chat_reactions, public.eige_reaction_rate_limit from public,anon,authenticated;
grant all on table public.eige_chat_reactions, public.eige_reaction_rate_limit to service_role;

create or replace function public.eige_project_chat_read(p_telegram_id bigint,p_project_id uuid)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; result jsonb;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return jsonb_build_object('error','forbidden'); end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return jsonb_build_object('error','blocked'); end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',q.id,'name',q.name,'text',q.body,'created_at',q.created_at,'mine',q.sender_id=actor,
   'reactions',coalesce((select jsonb_agg(jsonb_build_object('reaction',r.reaction,'count',r.n,'mine',r.mine) order by r.reaction)
       from (select reaction,count(*)::int n,bool_or(actor_id=actor) mine from public.eige_chat_reactions where message_id=q.id group by reaction) r),'[]'::jsonb))
   order by q.created_at,q.id),'[]'::jsonb) into result
 from (select m.id,m.sender_id,m.body,m.created_at,p.name from public.eige_project_messages m
       join public.eige_profiles p on p.id=m.sender_id where m.project_id=p_project_id
       order by m.created_at desc,m.id desc limit 100) q;
 return jsonb_build_object('ok',true,'messages',result);
end $$;

create or replace function public.eige_chat_toggle_reaction(p_telegram_id bigint,p_project_id uuid,p_message_id uuid,p_reaction text)
returns text language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; previous text; n integer;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return 'forbidden'; end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return 'blocked'; end if;
 if p_reaction is null or p_reaction not in ('like','heart','laugh','wow','sad','fire') then return 'invalid'; end if;
 perform 1 from public.eige_project_messages where id=p_message_id and project_id=p_project_id for key share;
 if not found then return 'not_found'; end if;
 insert into public.eige_reaction_rate_limit(telegram_id,window_started,attempts) values(p_telegram_id,now(),1)
 on conflict (telegram_id) do update set
 attempts=case when eige_reaction_rate_limit.window_started<=now()-interval '1 minute' then 1 else least(eige_reaction_rate_limit.attempts+1,61) end,
 window_started=case when eige_reaction_rate_limit.window_started<=now()-interval '1 minute' then now() else eige_reaction_rate_limit.window_started end returning attempts into n;
 if n>60 then return 'rate_limited'; end if;
 select reaction into previous from public.eige_chat_reactions where message_id=p_message_id and actor_id=actor;
 if previous=p_reaction then
   delete from public.eige_chat_reactions where message_id=p_message_id and actor_id=actor;
 else
   insert into public.eige_chat_reactions(message_id,actor_id,reaction) values(p_message_id,actor,p_reaction)
   on conflict(message_id,actor_id) do update set reaction=excluded.reaction,created_at=now();
 end if;
 return 'ok';
end $$;
revoke all on function public.eige_project_chat_read(bigint,uuid),public.eige_chat_toggle_reaction(bigint,uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.eige_project_chat_read(bigint,uuid),public.eige_chat_toggle_reaction(bigint,uuid,uuid,text) to service_role;
commit;
