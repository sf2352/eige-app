begin;
alter table public.eige_project_messages add column if not exists reply_to uuid references public.eige_project_messages(id) on delete set null;
alter table public.eige_project_messages add column if not exists is_reply boolean not null default false;
create index if not exists eige_messages_reply_idx on public.eige_project_messages(reply_to);
create table if not exists public.eige_project_telegram_groups (
 project_id uuid primary key references public.eige_projects(id) on delete cascade,
 invite_url text not null check (length(invite_url)<=200),
 updated_at timestamptz not null default now()
);
alter table public.eige_project_telegram_groups enable row level security;
revoke all on table public.eige_project_telegram_groups from public,anon,authenticated;
grant all on table public.eige_project_telegram_groups to service_role;
create or replace function public.eige_project_chat_read(p_telegram_id bigint,p_project_id uuid)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; result jsonb;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return jsonb_build_object('error','forbidden'); end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return jsonb_build_object('error','blocked'); end if;
 select coalesce(jsonb_agg(jsonb_build_object('id',q.id,'name',q.name,'text',q.body,'created_at',q.created_at,'mine',q.sender_id=actor,
   'reply',case when q.is_reply then coalesce((select jsonb_build_object('name',p2.name,'text',left(m2.body,140)) from public.eige_project_messages m2 join public.eige_profiles p2 on p2.id=m2.sender_id where m2.id=q.reply_to and m2.project_id=p_project_id),jsonb_build_object('deleted',true)) else null end,
   'reactions',coalesce((select jsonb_agg(jsonb_build_object('reaction',r.reaction,'count',r.n,'mine',r.mine) order by r.reaction)
       from (select reaction,count(*)::int n,bool_or(actor_id=actor) mine from public.eige_chat_reactions where message_id=q.id group by reaction) r),'[]'::jsonb))
   order by q.created_at,q.id),'[]'::jsonb) into result
 from (select m.id,m.sender_id,m.body,m.created_at,m.reply_to,m.is_reply,p.name from public.eige_project_messages m
       join public.eige_profiles p on p.id=m.sender_id where m.project_id=p_project_id
       order by m.created_at desc,m.id desc limit 100) q;
 return jsonb_build_object('ok',true,'messages',result);
end $$;

create or replace function public.eige_project_chat_reply(p_telegram_id bigint,p_project_id uuid,p_body text,p_reply_to uuid)
returns text language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; n int;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return 'forbidden'; end if;
 if p_body is null or char_length(trim(p_body))<1 or char_length(p_body)>500 then return 'invalid'; end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return 'blocked'; end if;
 perform 1 from public.eige_project_messages where id=p_reply_to and project_id=p_project_id for key share;
 if not found then return 'not_found'; end if;
 insert into public.eige_chat_rate_limit(telegram_id,window_started,attempts) values(p_telegram_id,now(),1)
 on conflict(telegram_id) do update set
 attempts=case when eige_chat_rate_limit.window_started<=now()-interval '1 minute' then 1 else least(eige_chat_rate_limit.attempts+1,6) end,
 window_started=case when eige_chat_rate_limit.window_started<=now()-interval '1 minute' then now() else eige_chat_rate_limit.window_started end returning attempts into n;
 if n>5 then return 'rate_limited'; end if;
 insert into public.eige_project_messages(project_id,sender_id,body,reply_to,is_reply) values(p_project_id,actor,trim(p_body),p_reply_to,true);
 return 'ok';
end $$;

-- Both functions check membership in the transaction. Only owner can set or remove the URL.
create or replace function public.eige_project_group_get(p_telegram_id bigint,p_project_id uuid)
returns jsonb language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; link text;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return jsonb_build_object('error','forbidden'); end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return jsonb_build_object('error','blocked'); end if;
 select invite_url into link from public.eige_project_telegram_groups where project_id=p_project_id;
 return jsonb_build_object('ok',true,'url',link);
end $$;
create or replace function public.eige_project_group_set(p_telegram_id bigint,p_project_id uuid,p_url text)
returns text language plpgsql security invoker set search_path=public,pg_temp as $$
declare actor uuid; owner_id uuid;
begin
 actor:=public.eige_chat_actor(p_telegram_id,p_project_id);
 if actor is null then return 'forbidden'; end if;
 perform pg_advisory_xact_lock(hashtextextended('eige-chat:'||p_telegram_id::text,0));
 if exists(select 1 from public.eige_chat_blocks where telegram_id=p_telegram_id) then return 'blocked'; end if;
 select p.owner_id into owner_id from public.eige_projects p where p.id=p_project_id;
 if owner_id is distinct from actor then return 'forbidden'; end if;
 if p_url is null or p_url='' then
   delete from public.eige_project_telegram_groups where project_id=p_project_id;
   return 'ok';
 end if;
 if length(p_url)>200 or p_url !~ '^https://t[.]me/(\+[A-Za-z0-9_-]{8,128}|joinchat/[A-Za-z0-9_-]{8,128}|[A-Za-z][A-Za-z0-9_]{3,31})$' then return 'invalid'; end if;
 insert into public.eige_project_telegram_groups(project_id,invite_url) values(p_project_id,p_url)
 on conflict(project_id) do update set invite_url=excluded.invite_url,updated_at=now();
 return 'ok';
end $$;
revoke all on function public.eige_project_chat_read(bigint,uuid),public.eige_project_chat_reply(bigint,uuid,text,uuid),public.eige_project_group_get(bigint,uuid),public.eige_project_group_set(bigint,uuid,text) from public,anon,authenticated;
grant execute on function public.eige_project_chat_read(bigint,uuid),public.eige_project_chat_reply(bigint,uuid,text,uuid),public.eige_project_group_get(bigint,uuid),public.eige_project_group_set(bigint,uuid,text) to service_role;
commit;
