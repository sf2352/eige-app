begin;
alter table public.eige_profiles add column if not exists country text;
alter table public.eige_profiles add column if not exists show_country boolean not null default false;
alter table public.eige_projects add column if not exists country text;
-- Только сервер вызывает функцию, устанавливая telegram_id из подписанных данных Telegram.
create or replace function public.eige_delete_my_account(p_telegram_id bigint)
returns boolean language plpgsql security invoker set search_path = public, pg_temp as $$
declare profile_id uuid; project record; ok boolean;
begin
  select id into profile_id from public.eige_profiles where telegram_id=p_telegram_id for update;
  if not found then return false; end if;
  for project in select id from public.eige_projects where owner_id=profile_id loop
    select public.eige_delete_owned_project(project.id,profile_id) into ok;
    if not ok then raise exception 'project deletion failed'; end if;
  end loop;
  delete from public.eige_project_messages where sender_id=profile_id;
  delete from public.eige_requests where sender_id=profile_id or recipient_id=profile_id;
  delete from public.eige_profiles where id=profile_id;
  return found;
end $$;
revoke all on function public.eige_delete_my_account(bigint) from public, anon, authenticated;
grant execute on function public.eige_delete_my_account(bigint) to service_role;

-- Защитить новые поля от прямого доступа обычных клиентских ролей.
revoke all (country, show_country) on table public.eige_profiles from public, anon, authenticated;
commit;
