begin;

-- Проверка статуса: ранее выданные пользователями себе роли остаются неподтверждёнными.
alter table public.eige_profiles add column if not exists role_verified boolean not null default false;

-- При смене роли, имени или профессии подтверждение сбрасывается автоматически.
create or replace function public.eige_clear_verification_on_role_change()
returns trigger language plpgsql security invoker set search_path = public, pg_temp as $$
begin
  if new.role is distinct from old.role or new.name is distinct from old.name or new.profession is distinct from old.profession then new.role_verified := false; end if;
  return new;
end;
$$;
drop trigger if exists eige_role_verification_reset on public.eige_profiles;
create trigger eige_role_verification_reset before update on public.eige_profiles
for each row execute function public.eige_clear_verification_on_role_change();

-- Клиентские роли не обращаются к анкетам напрямую: только через Edge Function.
-- Убираем как права на таблицу, так и возможные отдельные права на столбцы.
alter table public.eige_profiles enable row level security;
revoke all on table public.eige_profiles from public, anon, authenticated;
do $$
declare col record;
begin
  for col in select column_name from information_schema.columns
    where table_schema='public' and table_name='eige_profiles' loop
    execute format('revoke all (%I) on table public.eige_profiles from public, anon, authenticated', col.column_name);
  end loop;
end;
$$;

-- Технический журнал действий и ограничение попыток ввода пароля.
create table if not exists public.eige_admin_audit (
  id uuid primary key default gen_random_uuid(),
  actor_telegram_id bigint not null,
  action text not null,
  target_id uuid,
  created_at timestamptz not null default now()
);
create table if not exists public.eige_admin_rate_limit (
  telegram_id bigint primary key,
  window_started timestamptz not null default now(),
  attempts integer not null default 0
);
alter table public.eige_admin_audit enable row level security;
alter table public.eige_admin_rate_limit enable row level security;
revoke all on table public.eige_admin_audit, public.eige_admin_rate_limit from public, anon, authenticated;
grant all on table public.eige_admin_audit, public.eige_admin_rate_limit to service_role;

-- Не более пяти попыток входа за 15 минут для разрешённого Telegram ID.
create or replace function public.eige_admin_try_login(p_telegram_id bigint)
returns boolean language plpgsql security invoker set search_path = public, pg_temp as $$
declare n integer;
begin
  insert into public.eige_admin_rate_limit(telegram_id,window_started,attempts)
  values(p_telegram_id,now(),1)
  on conflict (telegram_id) do update set
    attempts = case when eige_admin_rate_limit.window_started <= now() - interval '15 minutes' then 1 else least(eige_admin_rate_limit.attempts + 1, 6) end,
    window_started = case when eige_admin_rate_limit.window_started <= now() - interval '15 minutes' then now() else eige_admin_rate_limit.window_started end
  returning attempts into n;
  return n <= 5;
end;
$$;

-- Подтверждать можно только педагога или специалиста, но не свою анкету; имя, роль и профессия должны совпадать с просмотренными.
-- Журнал пишется в той же транзакции.
create or replace function public.eige_admin_verify_role(p_profile_id uuid, p_verified boolean, p_actor_telegram_id bigint, p_expected_role text, p_expected_name text, p_expected_profession text)
returns boolean language plpgsql security invoker set search_path = public, pg_temp as $$
begin
  update public.eige_profiles set role_verified = p_verified
  where id = p_profile_id and role in ('Педагог','Специалист / предприниматель')
    and role = p_expected_role and name = p_expected_name and coalesce(profession, '') = p_expected_profession
    and telegram_id <> p_actor_telegram_id and p_verified is not null;
  if not found then return false; end if;
  insert into public.eige_admin_audit(actor_telegram_id,action,target_id)
  values(p_actor_telegram_id, case when p_verified then 'verify_role' else 'unverify_role' end, p_profile_id);
  return true;
end;
$$;

-- Удаление проекта и связанных записей — одной транзакцией.
create or replace function public.eige_admin_delete_project(p_project_id uuid, p_actor_telegram_id bigint)
returns boolean language plpgsql security invoker set search_path = public, pg_temp as $$
declare owner uuid; ok boolean;
begin
  select owner_id into owner from public.eige_projects where id = p_project_id for update;
  if not found then return false; end if;
  select public.eige_delete_owned_project(p_project_id, owner) into ok;
  if not ok then return false; end if;
  insert into public.eige_admin_audit(actor_telegram_id,action,target_id) values(p_actor_telegram_id,'delete_project',p_project_id);
  return true;
end;
$$;

-- Безвозвратное удаление профиля, его проектов, связанных заявок и сообщений.
-- Операция не позволяет администратору удалить собственную анкету.
create or replace function public.eige_admin_delete_profile(p_profile_id uuid, p_actor_telegram_id bigint)
returns boolean language plpgsql security invoker set search_path = public, pg_temp as $$
declare target_telegram_id bigint; project record;
begin
  select telegram_id into target_telegram_id from public.eige_profiles where id = p_profile_id for update;
  if not found or target_telegram_id = p_actor_telegram_id then return false; end if;
  for project in select id from public.eige_projects where owner_id = p_profile_id loop
    perform public.eige_delete_owned_project(project.id, p_profile_id);
  end loop;
  delete from public.eige_project_messages where sender_id = p_profile_id;
  delete from public.eige_requests where sender_id = p_profile_id or recipient_id = p_profile_id;
  delete from public.eige_profiles where id = p_profile_id;
  if not found then return false; end if;
  insert into public.eige_admin_audit(actor_telegram_id,action,target_id) values(p_actor_telegram_id,'delete_profile',p_profile_id);
  return true;
end;
$$;

revoke all on function public.eige_admin_try_login(bigint) from public, anon, authenticated;
revoke all on function public.eige_admin_verify_role(uuid, boolean, bigint, text, text, text) from public, anon, authenticated;
revoke all on function public.eige_admin_delete_project(uuid, bigint) from public, anon, authenticated;
revoke all on function public.eige_admin_delete_profile(uuid, bigint) from public, anon, authenticated;
grant execute on function public.eige_admin_try_login(bigint) to service_role;
grant execute on function public.eige_admin_verify_role(uuid, boolean, bigint, text, text, text) to service_role;
grant execute on function public.eige_admin_delete_project(uuid, bigint) to service_role;
grant execute on function public.eige_admin_delete_profile(uuid, bigint) to service_role;

commit;
